package com.nova.driver;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
