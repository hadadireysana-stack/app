import { History, MapPin, Star } from 'lucide-react'
import { faDate, faTime, toFa, toman, type Trip } from '@nova/shared'

export function TripsScreen({ trips }: { trips: Trip[] }) {
  return (
    <div className="screen">
      <div className="screen-title">سفرهای انجام‌شده</div>
      {trips.length === 0 && (
        <div className="empty">
          <History size={34} />
          <p>هنوز سفری انجام نداده‌اید</p>
          <span className="muted small">کلید آنلاین را بزنید و اولین سفارش را بپذیرید</span>
        </div>
      )}
      <div className="trip-list">
        {trips.map((t) => (
          <div key={t.id} className="trip-card">
            <div className="row between">
              <span className="chip class-chip">{t.carClassName}</span>
              <span className="muted small">
                {faDate(t.dateISO)} · {faTime(t.dateISO)}
              </span>
            </div>
            <div className="trip-route">
              <div className="row">
                <MapPin size={14} style={{ color: '#059669', flex: 'none' }} />
                <span className="small">{t.fromName}</span>
              </div>
              <div className="row">
                <MapPin size={14} style={{ color: '#f59e0b', flex: 'none' }} />
                <span className="small">{t.toName}</span>
              </div>
            </div>
            <div className="row between">
              <span className="muted small">مسافر: {t.counterpartName}</span>
              {t.rating != null && (
                <span className="chip rating-chip">
                  <Star size={12} /> {toFa(t.rating)}
                </span>
              )}
            </div>
            <div className="row between">
              <span className="muted small">{toFa(t.distanceKm)} کیلومتر</span>
              <b className="fare">+ {toman(t.fare)}</b>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
