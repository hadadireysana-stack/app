import { useEffect, useRef, useState } from 'react'
import { MapPin, Power, UserRound } from 'lucide-react'
import {
  CAR_CLASSES,
  PASSENGER_NAMES,
  PLACES,
  distanceKm,
  driverShare,
  estimateFare,
  pickRandom,
  pointOnRoute,
  routePoints,
  toFa,
  toman,
  type CarClassId,
  type Place,
  type Point,
  type Trip,
} from '@nova/shared'
import { MapView } from '../MapView'

type Phase = 'idle' | 'offer' | 'toPickup' | 'atPickup' | 'inTrip' | 'summary'

interface Offer {
  passenger: string
  pickup: Place
  dest: Place
  distanceKm: number
  fare: number
  cut: number
  carClassName: string
  carClass: CarClassId
}

interface Props {
  online: boolean
  onTripDone: (trip: Trip, ratingGiven: number) => void
}

const OFFER_TTL = 12000
const TO_PICKUP_MS = 6000
const TRIP_MS = 8000

export function HomeScreen({ online, onTripDone }: Props) {
  const [phase, setPhase] = useState<Phase>('idle')
  const [offer, setOffer] = useState<Offer | null>(null)
  const offerRef = useRef<Offer | null>(null)
  offerRef.current = offer
  const [offerLeft, setOfferLeft] = useState(OFFER_TTL)
  const [car, setCar] = useState<Point | null>(null)
  const [carStart, setCarStart] = useState<Point>({ x: 50, y: 50 })
  const [progress, setProgress] = useState(0)
  const [lastEarn, setLastEarn] = useState(0)

  /* تولید خودکار سفارش در حالت آنلاین و بیکار */
  useEffect(() => {
    if (!online) {
      setPhase('idle')
      setOffer(null)
      setCar(null)
      return
    }
    if (phase !== 'idle') return
    const wait = 4000 + Math.random() * 5000
    const t = window.setTimeout(() => {
      const pickup = pickRandom(PLACES)
      const others = PLACES.filter((p) => p.id !== pickup.id)
      const dest = pickRandom(others)
      const cls = pickRandom(CAR_CLASSES.slice(0, 2))
      const dist = distanceKm(pickup, dest)
      const fare = estimateFare(dist, cls.factor)
      const startPlace = pickRandom(PLACES)
      setCarStart({ x: startPlace.x, y: startPlace.y })
      setOffer({
        passenger: pickRandom(PASSENGER_NAMES),
        pickup,
        dest,
        distanceKm: dist,
        fare,
        cut: driverShare(fare),
        carClassName: cls.name,
        carClass: cls.id,
      })
      setOfferLeft(OFFER_TTL)
      setPhase('offer')
    }, wait)
    return () => window.clearTimeout(t)
  }, [online, phase])

  /* شمارش معکوس پذیرش سفارش */
  useEffect(() => {
    if (phase !== 'offer') return
    const t0 = Date.now()
    const iv = window.setInterval(() => {
      const left = Math.max(0, OFFER_TTL - (Date.now() - t0))
      setOfferLeft(left)
      if (left <= 0) {
        window.clearInterval(iv)
        setOffer(null)
        setPhase('idle')
      }
    }, 100)
    return () => window.clearInterval(iv)
  }, [phase])

  /* حرکت خودرو در دو فاز رفتن به مبدأ و انجام سفر */
  useEffect(() => {
    if (phase === 'toPickup' && offer) {
      const route = routePoints(carStart, { x: offer.pickup.x, y: offer.pickup.y })
      setCar({ ...carStart })
      const t0 = Date.now()
      const iv = window.setInterval(() => {
        const p = Math.min(1, (Date.now() - t0) / TO_PICKUP_MS)
        setProgress(p)
        setCar(pointOnRoute(route, p))
        if (p >= 1) {
          window.clearInterval(iv)
          setPhase('atPickup')
        }
      }, 60)
      return () => window.clearInterval(iv)
    }

    if (phase === 'inTrip' && offer) {
      const route = routePoints(
        { x: offer.pickup.x, y: offer.pickup.y },
        { x: offer.dest.x, y: offer.dest.y },
      )
      setProgress(0)
      const t0 = Date.now()
      const iv = window.setInterval(() => {
        const p = Math.min(1, (Date.now() - t0) / TRIP_MS)
        setProgress(p)
        setCar(pointOnRoute(route, p))
        if (p >= 1) {
          window.clearInterval(iv)
          finishRide()
        }
      }, 60)
      return () => window.clearInterval(iv)
    }

    if (phase === 'summary') {
      const t = window.setTimeout(() => {
        setOffer(null)
        setCar(null)
        setPhase('idle')
      }, 3000)
      return () => window.clearTimeout(t)
    }
  }, [phase, offer, carStart])

  function reject() {
    setOffer(null)
    setPhase('idle')
  }

  /* ثبت سفر، درآمد و امتیاز پس از پایان مسیر */
  function finishRide() {
    if (!offerRef.current) return
    const offer = offerRef.current
    const rawRating = 4.5 + Math.random() * 0.5
    const ratingGiven = Math.round(rawRating * 10) / 10
    const trip: Trip = {
      id: `d-${Date.now()}`,
      dateISO: new Date().toISOString(),
      fromName: offer.pickup.name,
      toName: offer.dest.name,
      distanceKm: offer.distanceKm,
      fare: offer.cut,
      carClass: offer.carClass,
      carClassName: offer.carClassName,
      counterpartName: offer.passenger,
      rating: ratingGiven,
    }
    setLastEarn(offer.cut)
    onTripDone(trip, ratingGiven)
    setPhase('summary')
  }

  const pickupPoint: Point | null = offer ? { x: offer.pickup.x, y: offer.pickup.y } : null
  const destPoint: Point | null = offer ? { x: offer.dest.x, y: offer.dest.y } : null
  const route =
    phase === 'toPickup' && offer
      ? routePoints(carStart, { x: offer.pickup.x, y: offer.pickup.y })
      : phase === 'inTrip' && offer
        ? routePoints(
            { x: offer.pickup.x, y: offer.pickup.y },
            { x: offer.dest.x, y: offer.dest.y },
          )
        : null

  return (
    <div className="main">
      <div className="map-box">
        <MapView
          pickup={pickupPoint ?? carStart}
          dest={destPoint}
          car={car}
          route={route}
          searching={online && phase === 'idle'}
        />
      </div>

      <div className="map-card">
        {!online && (
          <div className="card center-card">
            <Power size={34} style={{ color: '#a8a29e' }} />
            <div className="card-title center">آفلاین هستید</div>
            <div className="muted small center">
              برای دریافت سفارش، کلید آنلاین بالای صفحه را فعال کنید.
            </div>
          </div>
        )}

        {online && phase === 'idle' && (
          <div className="card center-card">
            <Power size={34} style={{ color: '#059669' }} />
            <div className="card-title center">آنلاین — در حال دریافت سفارش</div>
            <div className="muted small center">
              به محض ثبت سفارش جدید در نزدیکی شما، مطلع می‌شوید.
            </div>
            <div className="row center">
              <span className="spinner" />
            </div>
          </div>
        )}

        {phase === 'offer' && offer && (
          <>
            <div className="status-banner amber">سفارش جدید در نزدیکی شما</div>
            <div className="row between">
              <span className="chip class-chip">{offer.carClassName}</span>
              <span className="muted small">{toFa(offer.distanceKm)} کیلومتر</span>
            </div>
            <div className="trip-route">
              <div className="row">
                <MapPin size={14} style={{ color: '#059669', flex: 'none' }} />
                <span className="small">{offer.pickup.name}</span>
              </div>
              <div className="row">
                <MapPin size={14} style={{ color: '#f59e0b', flex: 'none' }} />
                <span className="small">{offer.dest.name}</span>
              </div>
            </div>
            <div className="row between">
              <span className="muted small">مسافر: {offer.passenger}</span>
              <b className="fare">{toman(offer.cut)}</b>
            </div>
            <div className="note">سهم شما پس از کسر کمیسیون ۱۸٪ پلتفرم</div>
            <div className="offer-countdown">
              <i style={{ width: `${(offerLeft / OFFER_TTL) * 100}%` }} />
            </div>
            <div className="row gap">
              <button className="btn btn-primary grow" onClick={() => setPhase('toPickup')}>
                پذیرش سفارش
              </button>
              <button className="btn btn-ghost" onClick={reject}>
                رد
              </button>
            </div>
          </>
        )}

        {phase === 'toPickup' && offer && (
          <>
            <div className="status-banner">در حال رفتن به محل مسافر</div>
            <div className="row between">
              <span className="muted small">مقصد: {offer.pickup.name}</span>
              <span className="chip rating-chip">
                <UserRound size={12} /> {offer.passenger}
              </span>
            </div>
            <div className="progress">
              <i style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
            <button className="btn btn-ghost" onClick={reject}>
              لغو سفارش
            </button>
          </>
        )}

        {phase === 'atPickup' && offer && (
          <>
            <div className="status-banner">به مسافر رسیدید</div>
            <div className="muted small center">مسافر سوار می‌شود...</div>
            <button className="btn btn-primary" onClick={() => setPhase('inTrip')}>
              شروع سفر به {offer.dest.name}
            </button>
          </>
        )}

        {phase === 'inTrip' && offer && (
          <>
            <div className="status-banner">در حال سفر به {offer.dest.name}</div>
            <div className="progress">
              <i style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
            <div className="row between">
              <span className="muted small">{toFa(Math.round(progress * 100))}٪ مسیر طی شده</span>
              <span className="fare">{toman(offer.cut)}</span>
            </div>
          </>
        )}

        {phase === 'summary' && offer && (
          <>
            <div className="status-banner">سفر با موفقیت انجام شد</div>
            <div className="row between">
              <span className="muted small">درآمد این سفر</span>
              <b className="fare">+ {toman(lastEarn)}</b>
            </div>
            <div className="muted small center">در حال بازگشت به حالت دریافت سفارش...</div>
          </>
        )}
      </div>
    </div>
  )
}
