import { Info, UserRound } from 'lucide-react'
import { toFa, toman, type DriverEarnings } from '@nova/shared'

interface Props {
  earnings: DriverEarnings
  online: boolean
}

export function ProfileScreen({ earnings, online }: Props) {
  return (
    <div className="screen">
      <div className="profile-hero">
        <div className="avatar big">
          <UserRound size={30} />
        </div>
        <div className="grow">
          <div className="card-title">راننده نوا</div>
          <div className="muted small">{online ? 'وضعیت: آنلاین' : 'وضعیت: آفلاین'}</div>
        </div>
        <span className={`switch ${online ? 'on' : ''}`} aria-hidden="true">
          <span className="knob" />
        </span>
      </div>

      <div className="card">
        <div className="card-title">مشخصات خودرو</div>
        <div className="row between">
          <span className="muted small">خودرو</span>
          <span>پژو ۲۰۷ سفید</span>
        </div>
        <div className="row between">
          <span className="muted small">پلاک</span>
          <span className="plate">۴۵ ط ۷۸۹ | ایران ۳۱</span>
        </div>
        <div className="row between">
          <span className="muted small">کمیسیون پلتفرم</span>
          <span>۱۸٪</span>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat">
          <b>{toFa(earnings.totalRides)}</b>
          <span className="muted small">سفر در تاریخ اپ</span>
        </div>
        <div className="stat">
          <b>{toman(earnings.totalEarnings)}</b>
          <span className="muted small">درآمد کل</span>
        </div>
      </div>

      <div className="card demo-card">
        <div className="row">
          <Info size={16} />
          <b>نسخه نمایشی</b>
        </div>
        <p className="muted small" style={{ margin: 0 }}>
          سفارش‌ها شبیه‌سازی می‌شوند تا بتوانید کل جریان دریافت و انجام سفر را بدون سرور امتحان
          کنید. اتصال به سامانه واقعی اعزام سفارش در نسخه‌های بعدی اضافه می‌شود.
        </p>
      </div>

      <div className="muted small center">نوا راننده — نسخه ۱.۰.۰</div>
    </div>
  )
}
