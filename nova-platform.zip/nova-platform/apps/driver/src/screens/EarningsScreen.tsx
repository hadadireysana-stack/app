import { Star } from 'lucide-react'
import { faTime, ratingText, toFa, toman, type DriverEarnings, type Trip } from '@nova/shared'

interface Props {
  earnings: DriverEarnings
  trips: Trip[]
}

export function EarningsScreen({ earnings, trips }: Props) {
  const recent = trips.slice(0, 5)

  return (
    <div className="screen">
      <div className="screen-title">درآمد</div>

      <div className="balance-card">
        <div className="muted small">درآمد امروز</div>
        <div className="fare-big">{toman(earnings.todayEarnings)}</div>
        <div className="muted small">{toFa(earnings.todayRides)} سفر امروز</div>
      </div>

      <div className="stat-grid">
        <div className="stat">
          <b>{toman(earnings.totalEarnings)}</b>
          <span className="muted small">مجموع درآمد</span>
        </div>
        <div className="stat">
          <b>{toFa(earnings.totalRides)}</b>
          <span className="muted small">مجموع سفرها</span>
        </div>
        <div className="stat">
          <b className="row">
            <Star size={16} style={{ color: '#f59e0b', fill: '#f59e0b' }} /> {ratingText(earnings.rating)}
          </b>
          <span className="muted small">امتیاز رانندگی</span>
        </div>
        <div className="stat">
          <b>{toFa(earnings.ratedCount)}</b>
          <span className="muted small">تعداد امتیازها</span>
        </div>
      </div>

      <div className="card">
        <div className="card-title">آخرین درآمدها</div>
        {recent.length === 0 && <div className="muted small center">هنوز سفری ثبت نشده است</div>}
        <div className="trip-list">
          {recent.map((t) => (
            <div key={t.id} className="row between">
              <span className="small">{t.toName}</span>
              <span className="row">
                <span className="muted small">{faTime(t.dateISO)}</span>
                <b className="fare">+ {toman(t.fare)}</b>
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
