import { useEffect, useState } from 'react'
import { Banknote, History, Route, UserRound } from 'lucide-react'
import {
  DRIVER_EARNINGS_KEY,
  DRIVER_TRIPS_KEY,
  loadJSON,
  saveJSON,
  type DriverEarnings,
  type Trip,
} from '@nova/shared'
import { HomeScreen } from './screens/HomeScreen'
import { EarningsScreen } from './screens/EarningsScreen'
import { TripsScreen } from './screens/TripsScreen'
import { ProfileScreen } from './screens/ProfileScreen'

const DEFAULT_EARNINGS: DriverEarnings = {
  dateKey: new Date().toISOString().slice(0, 10),
  todayRides: 0,
  todayEarnings: 0,
  totalRides: 0,
  totalEarnings: 0,
  rating: 4.7,
  ratedCount: 0,
}

type Tab = 'home' | 'earnings' | 'trips' | 'profile'

export default function App() {
  const [tab, setTab] = useState<Tab>('home')
  const [online, setOnline] = useState(false)
  const [earnings, setEarnings] = useState<DriverEarnings>(DEFAULT_EARNINGS)
  const [trips, setTrips] = useState<Trip[]>([])
  const [ready, setReady] = useState(false)

  useEffect(() => {
    let alive = true
    Promise.all([
      loadJSON<DriverEarnings>(DRIVER_EARNINGS_KEY, DEFAULT_EARNINGS),
      loadJSON<Trip[]>(DRIVER_TRIPS_KEY, []),
    ]).then(([e, t]) => {
      if (!alive) return
      setEarnings(e)
      setTrips(t)
      setReady(true)
    })
    return () => {
      alive = false
    }
  }, [])

  useEffect(() => {
    if (ready) void saveJSON(DRIVER_EARNINGS_KEY, earnings)
  }, [earnings, ready])

  useEffect(() => {
    if (ready) void saveJSON(DRIVER_TRIPS_KEY, trips)
  }, [trips, ready])

  function handleTripDone(trip: Trip, ratingGiven: number) {
    setTrips((t) => [trip, ...t])
    setEarnings((e) => {
      const tk = new Date().toISOString().slice(0, 10)
      const same = e.dateKey === tk
      return {
        dateKey: tk,
        todayRides: (same ? e.todayRides : 0) + 1,
        todayEarnings: (same ? e.todayEarnings : 0) + trip.fare,
        totalRides: e.totalRides + 1,
        totalEarnings: e.totalEarnings + trip.fare,
        ratedCount: e.ratedCount + 1,
        rating: (e.rating * e.ratedCount + ratingGiven) / (e.ratedCount + 1),
      }
    })
  }

  function navCls(id: Tab): string {
    return `nav-btn ${tab === id ? 'active' : ''}`
  }

  return (
    <div className="app">
      <header className="header">
        <div className="brand">
          <div className="brand-logo driver">ن</div>
          <div>
            <div className="brand-title">نوا راننده</div>
            <div className="brand-sub">سفارش‌های اطراف شما</div>
          </div>
        </div>
        <button
          className={`switch ${online ? 'on' : ''}`}
          role="switch"
          aria-checked={online}
          aria-label="حالت آنلاین"
          onClick={() => setOnline(!online)}
        >
          <span className="knob" />
        </button>
      </header>

      <div className="body">
        {tab === 'home' && <HomeScreen online={online} onTripDone={handleTripDone} />}
        {tab === 'earnings' && <EarningsScreen earnings={earnings} trips={trips} />}
        {tab === 'trips' && <TripsScreen trips={trips} />}
        {tab === 'profile' && <ProfileScreen earnings={earnings} online={online} />}
      </div>

      <nav className="bottom-nav" aria-label="ناوبری اصلی">
        <button className={navCls('home')} onClick={() => setTab('home')}>
          <Route size={20} />
          <span>سفر</span>
        </button>
        <button className={navCls('earnings')} onClick={() => setTab('earnings')}>
          <Banknote size={20} />
          <span>درآمد</span>
        </button>
        <button className={navCls('trips')} onClick={() => setTab('trips')}>
          <History size={20} />
          <span>سفرها</span>
        </button>
        <button className={navCls('profile')} onClick={() => setTab('profile')}>
          <UserRound size={20} />
          <span>پروفایل</span>
        </button>
      </nav>
    </div>
  )
}
