import { fmtPath, type Point } from '@nova/shared'

interface MapViewProps {
  pickup: Point
  dest: Point | null
  car: Point | null
  route: Point[] | null
  searching?: boolean
}

/** بلوک‌های شهروار نقشه — مختصات روی شبکه ۱۰۰×۱۰۰ */
const BLOCKS: Array<[number, number, number, number]> = [
  [2, 2, 16, 10], [20, 2, 22, 8], [44, 2, 18, 12], [64, 2, 16, 10], [82, 2, 16, 14],
  [2, 14, 12, 14], [16, 12, 12, 16], [30, 12, 12, 18], [44, 16, 14, 12], [60, 14, 18, 12], [80, 18, 18, 12],
  [2, 30, 14, 16], [18, 30, 10, 14], [30, 32, 12, 12], [44, 30, 12, 14], [58, 28, 10, 16], [70, 28, 12, 14], [84, 30, 14, 12],
  [2, 48, 16, 12], [20, 46, 14, 14], [36, 46, 10, 16], [48, 46, 16, 10], [66, 44, 14, 12], [82, 44, 16, 16],
  [2, 62, 12, 14], [16, 60, 16, 12], [34, 64, 12, 10], [48, 60, 12, 14], [62, 58, 16, 12], [80, 62, 18, 12],
  [2, 78, 14, 10], [18, 74, 14, 14], [34, 76, 16, 12], [52, 76, 10, 14], [64, 72, 16, 16], [82, 76, 16, 12],
]

const PARKS = new Set([13, 23, 27])

export function MapView({ pickup, dest, car, route, searching }: MapViewProps) {
  return (
    <svg className="map" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" role="img" aria-label="نقشه شهر">
      <rect width="100" height="100" fill="#eef2ef" />
      {BLOCKS.map((b, i) => (
        <rect
          key={i}
          x={b[0]}
          y={b[1]}
          width={b[2]}
          height={b[3]}
          rx={1.2}
          fill={PARKS.has(i) ? '#d9ecd4' : '#e2e9e2'}
        />
      ))}
      {route && (
        <path
          className="route-flow"
          d={fmtPath(route)}
          fill="none"
          stroke="#059669"
          strokeWidth={1.1}
          strokeLinecap="round"
        />
      )}
      {searching && (
        <g>
          <circle className="pulse" cx={pickup.x} cy={pickup.y} r={4} fill="none" stroke="#059669" strokeWidth={0.8} />
          <circle className="pulse pulse-2" cx={pickup.x} cy={pickup.y} r={4} fill="none" stroke="#059669" strokeWidth={0.8} />
        </g>
      )}
      <circle cx={pickup.x} cy={pickup.y} r={2.6} fill="#059669" stroke="#fff" strokeWidth={0.9} />
      <text x={pickup.x} y={pickup.y - 4} fontSize={3.4} textAnchor="middle" fill="#047857" fontWeight="700">
        مبدأ
      </text>
      {dest && (
        <>
          <circle cx={dest.x} cy={dest.y} r={2.6} fill="#f59e0b" stroke="#fff" strokeWidth={0.9} />
          <text x={dest.x} y={dest.y - 4} fontSize={3.4} textAnchor="middle" fill="#b45309" fontWeight="700">
            مقصد
          </text>
        </>
      )}
      {car && (
        <g className="car-marker" style={{ transform: `translate(${car.x}px, ${car.y}px)` }}>
          <circle r={2.4} fill="#1c1917" stroke="#fff" strokeWidth={0.8} />
          <rect x={-1.3} y={-0.8} width={2.6} height={1.6} rx={0.5} fill="#fff" />
        </g>
      )}
    </svg>
  )
}
