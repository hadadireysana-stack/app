import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.nova.driver',
  appName: 'Nova Driver',
  webDir: 'dist',
}

export default config
