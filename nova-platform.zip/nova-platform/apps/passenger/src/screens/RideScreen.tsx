import { useEffect, useMemo, useState } from 'react'
import { CarFront, MapPin, Search, Star, UserRound, X } from 'lucide-react'
import {
  CAR_CLASSES,
  DRIVERS,
  PICKUP,
  PLACES,
  distanceKm,
  estimateFare,
  getCarClass,
  pickRandom,
  pointOnRoute,
  ratingText,
  routePoints,
  toFa,
  toman,
  type CarClassId,
  type DriverInfo,
  type Place,
  type Point,
  type RidePhase,
  type Trip,
} from '@nova/shared'
import { MapView } from '../MapView'

interface Props {
  balance: number
  onComplete: (trip: Trip) => void
}

const SEARCH_MS = 2800
const TO_PICKUP_MS = 6000
const TRIP_MS = 8000

export function RideScreen({ balance, onComplete }: Props) {
  const [phase, setPhase] = useState<RidePhase>('idle')
  const [query, setQuery] = useState('')
  const [dest, setDest] = useState<Place | null>(null)
  const [classId, setClassId] = useState<CarClassId>('economy')
  const [driver, setDriver] = useState<DriverInfo | null>(null)
  const [driverStart, setDriverStart] = useState<Point | null>(null)
  const [car, setCar] = useState<Point | null>(null)
  const [progress, setProgress] = useState(0)
  const [stars, setStars] = useState(0)

  const pickup: Point = { x: PICKUP.x, y: PICKUP.y }
  const destPoint: Point | null = dest ? { x: dest.x, y: dest.y } : null

  const tripRoute = useMemo(
    () => (dest ? routePoints(pickup, { x: dest.x, y: dest.y }) : null),
    [dest],
  )
  const driverRoute = useMemo(
    () => (driverStart ? routePoints(driverStart, pickup) : null),
    [driverStart],
  )

  const distance = dest ? distanceKm(PICKUP, dest) : 0
  const cls = getCarClass(classId)
  const fare = estimateFare(distance, cls.factor)

  const filtered = PLACES.filter((p) => p.name.includes(query.trim()))

  /* ماشین زمان‌بندی فازهای سفر */
  useEffect(() => {
    if (phase === 'requesting') {
      const t = window.setTimeout(() => {
        const d = pickRandom(DRIVERS)
        const start = pickRandom(PLACES)
        setDriver(d)
        setDriverStart({ x: start.x, y: start.y })
        setPhase('toPickup')
      }, SEARCH_MS)
      return () => window.clearTimeout(t)
    }

    if (phase === 'toPickup' && driverStart) {
      const route = routePoints(driverStart, pickup)
      setCar({ ...driverStart })
      const t0 = Date.now()
      const iv = window.setInterval(() => {
        const p = Math.min(1, (Date.now() - t0) / TO_PICKUP_MS)
        setProgress(p)
        setCar(pointOnRoute(route, p))
        if (p >= 1) {
          window.clearInterval(iv)
          setPhase('waitPickup')
        }
      }, 60)
      return () => window.clearInterval(iv)
    }

    if (phase === 'waitPickup') {
      const t = window.setTimeout(() => setPhase('inTrip'), 2400)
      return () => window.clearTimeout(t)
    }

    if (phase === 'inTrip' && dest) {
      const route = routePoints(pickup, { x: dest.x, y: dest.y })
      setProgress(0)
      const t0 = Date.now()
      const iv = window.setInterval(() => {
        const p = Math.min(1, (Date.now() - t0) / TRIP_MS)
        setProgress(p)
        setCar(pointOnRoute(route, p))
        if (p >= 1) {
          window.clearInterval(iv)
          setPhase('rating')
        }
      }, 60)
      return () => window.clearInterval(iv)
    }
  }, [phase, driverStart, dest])

  function reset() {
    setPhase('idle')
    setDest(null)
    setDriver(null)
    setDriverStart(null)
    setCar(null)
    setProgress(0)
    setStars(0)
    setQuery('')
  }

  function finishTrip() {
    if (!dest || !driver) return
    const trip: Trip = {
      id: `p-${Date.now()}`,
      dateISO: new Date().toISOString(),
      fromName: PICKUP.name,
      toName: dest.name,
      distanceKm: distanceKm(PICKUP, dest),
      fare,
      carClass: classId,
      carClassName: cls.name,
      counterpartName: driver.name,
      counterpartCar: driver.car,
      rating: stars || 5,
    }
    onComplete(trip)
    reset()
  }

  const etaMin = Math.max(1, Math.ceil((1 - progress) * 4))
  const activeRoute = phase === 'toPickup' || phase === 'waitPickup' ? driverRoute : tripRoute

  return (
    <div className="main">
      <div className="map-box">
        <MapView
          pickup={pickup}
          dest={destPoint}
          car={car}
          route={activeRoute}
          searching={phase === 'requesting'}
        />
      </div>

      <div className="map-card">
        {phase === 'idle' && (
          <>
            <div className="card-title">به کجا می‌روید؟</div>
            <div className="search-box">
              <Search size={16} className="muted" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="جستجوی مقصد..."
                aria-label="جستجوی مقصد"
              />
            </div>
            <div className="place-list">
              {filtered.map((p) => (
                <button
                  key={p.id}
                  className="place-item"
                  onClick={() => {
                    setDest(p)
                    setPhase('estimating')
                  }}
                >
                  <MapPin size={16} className="pin" />
                  <span>{p.name}</span>
                  <span className="place-km">{toFa(distanceKm(PICKUP, p))} کیلومتر</span>
                </button>
              ))}
              {filtered.length === 0 && <div className="empty small">مقصدی با این نام پیدا نشد</div>}
            </div>
          </>
        )}

        {phase === 'estimating' && dest && (
          <>
            <button className="link-back" onClick={() => setPhase('idle')}>
              <X size={14} /> تغییر مقصد
            </button>
            <div>
              <div className="muted small">از {PICKUP.name}</div>
              <div className="card-title">مقصد: {dest.name}</div>
              <div className="muted small">فاصله: {toFa(distance)} کیلومتر</div>
            </div>
            <div className="class-grid">
              {CAR_CLASSES.map((c) => (
                <button
                  key={c.id}
                  className={`class-card ${classId === c.id ? 'selected' : ''}`}
                  onClick={() => setClassId(c.id)}
                >
                  <div className="row">
                    <CarFront size={16} />
                    <b>{c.name}</b>
                  </div>
                  <div className="muted small">{c.desc}</div>
                  <div className="row between">
                    <span className="fare">{toman(estimateFare(distance, c.factor))}</span>
                    <span className="muted small">{toFa(c.seats)} نفره</span>
                  </div>
                </button>
              ))}
            </div>
            <button className="btn btn-primary" onClick={() => setPhase('requesting')}>
              درخواست سفر — {toman(fare)}
            </button>
            <div className="note">
              موجودی کیف پول: {toman(balance)}
              {balance < fare ? ' — پس از سفر منفی می‌شود (حالت نمایشی)' : ''}
            </div>
          </>
        )}

        {phase === 'requesting' && (
          <>
            <div className="row gap">
              <span className="spinner" />
              <div>
                <div className="card-title">در حال جستجوی نزدیک‌ترین راننده...</div>
                <div className="muted small">معمولاً کمتر از یک دقیقه طول می‌کشد</div>
              </div>
            </div>
            <button className="btn btn-ghost" onClick={reset}>لغو جستجو</button>
          </>
        )}

        {(phase === 'toPickup' || phase === 'waitPickup') && driver && (
          <>
            <div className="status-banner">
              {phase === 'toPickup' ? `راننده در راه است — رسیدن در حدود ${toFa(etaMin)} دقیقه` : 'راننده رسید؛ سوار شوید'}
            </div>
            <div className="driver-card">
              <div className="avatar">
                <UserRound size={22} />
              </div>
              <div className="grow">
                <div className="row between">
                  <b>{driver.name}</b>
                  <span className="chip rating-chip">
                    <Star size={12} /> {ratingText(driver.rating)}
                  </span>
                </div>
                <div className="muted small">
                  {driver.car} — پلاک <span className="plate">{driver.plate}</span>
                </div>
              </div>
            </div>
            {phase === 'toPickup' && (
              <div className="progress">
                <i style={{ width: `${Math.round(progress * 100)}%` }} />
              </div>
            )}
            {phase === 'waitPickup' && <div className="note center">در حال آماده‌سازی سفر...</div>}
            <button className="btn btn-danger" onClick={reset}>لغو سفر</button>
          </>
        )}

        {phase === 'inTrip' && dest && (
          <>
            <div className="status-banner">در حال سفر به {dest.name}</div>
            <div className="progress">
              <i style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
            <div className="row between">
              <span className="muted small">{toFa(Math.round(progress * 100))}٪ مسیر طی شده</span>
              <span className="fare">{toman(fare)}</span>
            </div>
            <div className="note">کرایه پس از رسیدن از کیف پول کسر می‌شود.</div>
          </>
        )}

        {phase === 'rating' && dest && (
          <>
            <div className="card-title center">سفر به پایان رسید</div>
            <div className="fare-big center">{toman(fare)}</div>
            <div className="muted small center">پرداخت از کیف پول نوا</div>
            <div className="stars" role="group" aria-label="امتیاز به راننده">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  className="star"
                  onClick={() => setStars(n)}
                  aria-label={`${n} ستاره`}
                >
                  <Star
                    size={24}
                    fill={n <= stars ? '#f59e0b' : 'none'}
                    color={n <= stars ? '#f59e0b' : '#a8a29e'}
                  />
                </button>
              ))}
            </div>
            <button className="btn btn-primary" disabled={stars === 0} onClick={finishTrip}>
              ثبت امتیاز و پایان سفر
            </button>
          </>
        )}
      </div>
    </div>
  )
}
