import { Info, UserRound } from 'lucide-react'
import { toFa, toman, type Trip, type WalletState } from '@nova/shared'

interface Props {
  trips: Trip[]
  wallet: WalletState
}

export function ProfileScreen({ trips, wallet }: Props) {
  const spent = trips.reduce((s, t) => s + t.fare, 0)

  return (
    <div className="screen">
      <div className="profile-hero">
        <div className="avatar big">
          <UserRound size={30} />
        </div>
        <div>
          <div className="card-title">مسافر نوا</div>
          <div className="muted small">عضو از دی ۱۴۰۳</div>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat">
          <b>{toFa(trips.length)}</b>
          <span className="muted small">سفر ثبت‌شده</span>
        </div>
        <div className="stat">
          <b>{toman(spent)}</b>
          <span className="muted small">مجموع هزینه</span>
        </div>
        <div className="stat">
          <b>{toman(wallet.balance)}</b>
          <span className="muted small">موجودی کیف پول</span>
        </div>
        <div className="stat">
          <b>{toFa(4.8)}</b>
          <span className="muted small">امتیاز شما</span>
        </div>
      </div>

      <div className="card demo-card">
        <div className="row">
          <Info size={16} />
          <b>نسخه نمایشی</b>
        </div>
        <p className="muted small" style={{ margin: 0 }}>
          در این نسخه، راننده‌ها و سفارش‌ها شبیه‌سازی می‌شوند و داده‌ها فقط روی همین دستگاه ذخیره
          می‌شوند. اتصال به سرور واقعی در نسخه‌های بعدی اضافه می‌شود.
        </p>
      </div>

      <div className="muted small center">نوا مسافر — نسخه ۱.۰.۰</div>
    </div>
  )
}
