import { useState, type Dispatch, type SetStateAction } from 'react'
import { toman, type WalletState } from '@nova/shared'

interface Props {
  wallet: WalletState
  setWallet: Dispatch<SetStateAction<WalletState>>
}

const CHARGES = [50000, 100000, 250000]

export function WalletScreen({ wallet, setWallet }: Props) {
  const [code, setCode] = useState('')
  const [msg, setMsg] = useState<string | null>(null)
  const [ok, setOk] = useState(false)

  function applyPromo() {
    if (code.trim().toUpperCase() === 'NOVA') {
      if (wallet.promoUsed) {
        setOk(false)
        setMsg('این کد قبلاً استفاده شده است')
        return
      }
      setWallet((w) => ({ ...w, balance: w.balance + 50000, promoUsed: true }))
      setOk(true)
      setMsg('۵۰٬۰۰۰ تومان اعتبار هدیه اضافه شد')
    } else {
      setOk(false)
      setMsg('کد تخفیف معتبر نیست')
    }
    setCode('')
  }

  return (
    <div className="screen">
      <div className="screen-title">کیف پول</div>

      <div className="balance-card">
        <div className="muted small">موجودی فعلی</div>
        <div className="fare-big">{toman(wallet.balance)}</div>
        <div className="muted small">نسخه نمایشی — شارژها شبیه‌سازی می‌شوند</div>
      </div>

      <div className="card">
        <div className="card-title">شارژ نمایشی حساب</div>
        <div className="charge-grid">
          {CHARGES.map((c) => (
            <button
              key={c}
              className="btn btn-ghost"
              onClick={() => setWallet((w) => ({ ...w, balance: w.balance + c }))}
            >
              + {toman(c)}
            </button>
          ))}
        </div>
      </div>

      <div className="card">
        <div className="card-title">کد تخفیف</div>
        <div className="promo-row">
          <input
            className="promo-input"
            dir="ltr"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="NOVA"
            aria-label="کد تخفیف"
          />
          <button className="btn btn-primary narrow" onClick={applyPromo}>
            اعمال
          </button>
        </div>
        {msg && <div className={ok ? 'ok-text' : 'err-text'}>{msg}</div>}
      </div>
    </div>
  )
}
