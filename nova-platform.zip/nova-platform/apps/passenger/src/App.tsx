import { useEffect, useState } from 'react'
import { CarFront, History, UserRound, Wallet } from 'lucide-react'
import {
  PASSENGER_TRIPS_KEY,
  WALLET_KEY,
  loadJSON,
  saveJSON,
  toman,
  type Trip,
  type WalletState,
} from '@nova/shared'
import { RideScreen } from './screens/RideScreen'
import { HistoryScreen } from './screens/HistoryScreen'
import { WalletScreen } from './screens/WalletScreen'
import { ProfileScreen } from './screens/ProfileScreen'

const DEFAULT_WALLET: WalletState = { balance: 250000, promoUsed: false }

type Tab = 'ride' | 'history' | 'wallet' | 'profile'

export default function App() {
  const [tab, setTab] = useState<Tab>('ride')
  const [wallet, setWallet] = useState<WalletState>(DEFAULT_WALLET)
  const [trips, setTrips] = useState<Trip[]>([])
  const [ready, setReady] = useState(false)

  useEffect(() => {
    let alive = true
    Promise.all([
      loadJSON<WalletState>(WALLET_KEY, DEFAULT_WALLET),
      loadJSON<Trip[]>(PASSENGER_TRIPS_KEY, []),
    ]).then(([w, t]) => {
      if (!alive) return
      setWallet(w)
      setTrips(t)
      setReady(true)
    })
    return () => {
      alive = false
    }
  }, [])

  useEffect(() => {
    if (ready) void saveJSON(WALLET_KEY, wallet)
  }, [wallet, ready])

  useEffect(() => {
    if (ready) void saveJSON(PASSENGER_TRIPS_KEY, trips)
  }, [trips, ready])

  function handleTripComplete(trip: Trip) {
    setWallet((w) => ({ ...w, balance: w.balance - trip.fare }))
    setTrips((t) => [trip, ...t])
  }

  function navCls(id: Tab): string {
    return `nav-btn ${tab === id ? 'active' : ''}`
  }

  return (
    <div className="app">
      <header className="header">
        <div className="brand">
          <div className="brand-logo">ن</div>
          <div>
            <div className="brand-title">نوا مسافر</div>
            <div className="brand-sub">سفر شهری، ساده و مطمئن</div>
          </div>
        </div>
        <div className="wallet-chip" aria-label="موجودی کیف پول">
          <Wallet size={14} />
          <span>{toman(wallet.balance)}</span>
        </div>
      </header>

      <div className="body">
        {tab === 'ride' && <RideScreen balance={wallet.balance} onComplete={handleTripComplete} />}
        {tab === 'history' && <HistoryScreen trips={trips} />}
        {tab === 'wallet' && <WalletScreen wallet={wallet} setWallet={setWallet} />}
        {tab === 'profile' && <ProfileScreen trips={trips} wallet={wallet} />}
      </div>

      <nav className="bottom-nav" aria-label="ناوبری اصلی">
        <button className={navCls('ride')} onClick={() => setTab('ride')}>
          <CarFront size={20} />
          <span>سفر</span>
        </button>
        <button className={navCls('history')} onClick={() => setTab('history')}>
          <History size={20} />
          <span>سفرها</span>
        </button>
        <button className={navCls('wallet')} onClick={() => setTab('wallet')}>
          <Wallet size={20} />
          <span>کیف پول</span>
        </button>
        <button className={navCls('profile')} onClick={() => setTab('profile')}>
          <UserRound size={20} />
          <span>پروفایل</span>
        </button>
      </nav>
    </div>
  )
}
