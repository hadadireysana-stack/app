import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.nova.passenger',
  appName: 'Nova Passenger',
  webDir: 'dist',
}

export default config
