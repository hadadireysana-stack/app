package com.nova.passenger;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
