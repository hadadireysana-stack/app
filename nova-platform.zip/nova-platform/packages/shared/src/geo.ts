import type { Place } from './types'

export interface Point {
  x: number
  y: number
}

/** هر واحد شبکه نقشه معادل چند کیلومتر است */
export const GRID_TO_KM = 0.42

export function distanceKm(a: Place, b: Place): number {
  const dx = a.x - b.x
  const dy = a.y - b.y
  return Math.round(Math.sqrt(dx * dx + dy * dy) * GRID_TO_KM * 10) / 10
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t
}

/** مسیر با یک خمیدگی ملایم برای ظاهر طبیعی‌تر */
export function routePoints(from: Point, to: Point): Point[] {
  const midX = (from.x + to.x) / 2 + (to.y - from.y) * 0.16
  const midY = (from.y + to.y) / 2 - (to.x - from.x) * 0.16
  return [
    { x: from.x, y: from.y },
    { x: midX, y: midY },
    { x: to.x, y: to.y },
  ]
}

export function pointOnRoute(route: Point[], t: number): Point {
  if (t <= 0) return route[0]
  if (t >= 1) return route[route.length - 1]
  const seg1 = Math.hypot(route[1].x - route[0].x, route[1].y - route[0].y)
  const seg2 = Math.hypot(route[2].x - route[1].x, route[2].y - route[1].y)
  let d = t * (seg1 + seg2)
  if (d <= seg1) {
    const u = d / seg1
    return { x: lerp(route[0].x, route[1].x, u), y: lerp(route[0].y, route[1].y, u) }
  }
  d -= seg1
  const u = d / seg2
  return { x: lerp(route[1].x, route[2].x, u), y: lerp(route[1].y, route[2].y, u) }
}

export function fmtPath(route: Point[]): string {
  return route.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(' ')
}
