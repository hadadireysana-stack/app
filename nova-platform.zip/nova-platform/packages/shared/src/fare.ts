import type { CarClass, CarClassId } from './types'

export const CAR_CLASSES: CarClass[] = [
  { id: 'economy', name: 'اقتصادی', desc: 'سریع و به‌صرفه، مناسب سفر روزانه', factor: 1, seats: 4 },
  { id: 'comfort', name: 'راحتی', desc: 'ماشین‌های جدیدتر با فضای بیشتر', factor: 1.35, seats: 4 },
  { id: 'van', name: 'ون', desc: 'مناسب گروه‌ها و بار اضافه', factor: 1.75, seats: 7 },
]

const BASE_FARE = 14000
const PER_KM = 8800
const MIN_FARE = 24000

export function getCarClass(id: CarClassId): CarClass {
  return CAR_CLASSES.find((c) => c.id === id) ?? CAR_CLASSES[0]
}

export function estimateFare(distanceKm: number, factor: number): number {
  const raw = BASE_FARE + PER_KM * distanceKm * factor
  const rounded = Math.ceil(raw / 1000) * 1000
  return Math.max(rounded, MIN_FARE)
}

/** سهم راننده پس از کسر کمیسیون ۱۸ درصدی پلتفرم */
export function driverShare(fare: number): number {
  return Math.round((fare * 0.82) / 1000) * 1000
}
