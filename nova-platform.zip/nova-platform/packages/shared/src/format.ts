export function toFa(n: number): string {
  return n.toLocaleString('fa-IR', { useGrouping: true })
}

export function toman(n: number): string {
  return `${toFa(n)} تومان`
}

export function faDate(iso: string): string {
  return new Date(iso).toLocaleDateString('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}

export function faTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('fa-IR', {
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function ratingText(r: number): string {
  return toFa(Math.round(r * 10) / 10)
}

export function todayKey(): string {
  return new Date().toISOString().slice(0, 10)
}
