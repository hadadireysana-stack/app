import { Preferences } from '@capacitor/preferences'

export const WALLET_KEY = 'nova.wallet'
export const PASSENGER_TRIPS_KEY = 'nova.passenger.trips'
export const DRIVER_TRIPS_KEY = 'nova.driver.trips'
export const DRIVER_EARNINGS_KEY = 'nova.driver.earnings'

export async function loadJSON<T>(key: string, fallback: T): Promise<T> {
  try {
    const { value } = await Preferences.get({ key })
    if (!value) return fallback
    return JSON.parse(value) as T
  } catch {
    return fallback
  }
}

export async function saveJSON(key: string, value: unknown): Promise<void> {
  try {
    await Preferences.set({ key, value: JSON.stringify(value) })
  } catch {
    /* در حالت نمایشی نادیده گرفته می‌شود */
  }
}
