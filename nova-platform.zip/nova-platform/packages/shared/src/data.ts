import type { DriverInfo, Place } from './types'

export const PLACES: Place[] = [
  { id: 'azadi', name: 'میدان آزادی', x: 12, y: 80 },
  { id: 'ekbatan', name: 'شهرک اکباتان', x: 10, y: 58 },
  { id: 'mehrabad', name: 'فرودگاه مهرآباد', x: 6, y: 62 },
  { id: 'rahahan', name: 'ایستگاه راه‌آهن', x: 24, y: 88 },
  { id: 'terminal', name: 'ترمینال جنوب', x: 40, y: 95 },
  { id: 'bazaar', name: 'بازار بزرگ تهران', x: 44, y: 84 },
  { id: 'daneshgah', name: 'دانشگاه تهران', x: 38, y: 52 },
  { id: 'valiasr', name: 'پل وحید (ولیعصر)', x: 50, y: 44 },
  { id: 'vanak', name: 'میدان ونک', x: 56, y: 40 },
  { id: 'parkvi', name: 'پارک وی', x: 48, y: 30 },
  { id: 'melat', name: 'پارک ملت', x: 58, y: 30 },
  { id: 'tajrish', name: 'تجریش', x: 70, y: 12 },
  { id: 'milad', name: 'برج میلاد', x: 76, y: 20 },
  { id: 'office', name: 'مجموعه تجاری آرمان', x: 66, y: 34 },
]

export const PICKUP: Place = {
  id: 'pickup',
  name: 'موقعیت فعلی شما — میدان آزادی',
  x: 12,
  y: 80,
}

export const DRIVERS: DriverInfo[] = [
  { id: 'd1', name: 'امیر حسینی', car: 'پژو ۲۰۶ سفید', plate: '۱۲ ج ۴۵۶ | ایران ۲۲', rating: 4.8 },
  { id: 'd2', name: 'سعید محمدی', car: 'پژو پارس زرشکی', plate: '۷۴ ب ۹۱۱ | ایران ۴۳', rating: 4.9 },
  { id: 'd3', name: 'رضا کریمی', car: 'کوییک نقره‌ای', plate: '۳۳ د ۱۲۸ | ایران ۵۱', rating: 4.6 },
  { id: 'd4', name: 'مجتبی رضایی', car: 'سمند سفید', plate: '۸۸ ط ۵۶۰ | ایران ۲۹', rating: 4.7 },
  { id: 'd5', name: 'علی احمدی', car: 'دنا مشکی', plate: '۵۹ س ۲۳۴ | ایران ۶۴', rating: 4.9 },
]

export const PASSENGER_NAMES = [
  'مریم اسدی',
  'حسین توکلی',
  'نگار صالحی',
  'کامران فرد',
  'سارا مهدوی',
  'بهرام نیک‌منش',
  'الهام رستمی',
  'پویا صادقی',
]

export function pickRandom<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}
