export type CarClassId = 'economy' | 'comfort' | 'van'

export interface CarClass {
  id: CarClassId
  name: string
  desc: string
  factor: number
  seats: number
}

export interface Place {
  id: string
  name: string
  x: number
  y: number
}

export type RidePhase =
  | 'idle'
  | 'estimating'
  | 'requesting'
  | 'toPickup'
  | 'waitPickup'
  | 'inTrip'
  | 'rating'

export interface DriverInfo {
  id: string
  name: string
  car: string
  plate: string
  rating: number
}

export interface Trip {
  id: string
  dateISO: string
  fromName: string
  toName: string
  distanceKm: number
  fare: number
  carClass: CarClassId
  carClassName: string
  counterpartName: string
  counterpartCar?: string
  rating?: number
}

export interface WalletState {
  balance: number
  promoUsed: boolean
}

export interface DriverEarnings {
  dateKey: string
  todayRides: number
  todayEarnings: number
  totalRides: number
  totalEarnings: number
  rating: number
  ratedCount: number
}
