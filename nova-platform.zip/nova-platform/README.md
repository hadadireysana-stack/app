# نوا (Nova) — پلتفرم مسافر و راننده

دو اپلیکیشن اندرویدی کامل و فارسی برای مسافر و راننده، ساخته‌شده با React + TypeScript + Vite و بسته‌بندی‌شده با Capacitor 7. بیلد APK به‌صورت خودکار و رایگان روی GitHub Actions انجام می‌شود؛ هیچ نیازی به نصب Android Studio روی سیستم شما نیست.

## ساختار پروژه

```
nova-platform/
├─ apps/
│  ├─ passenger/          ← اپ مسافر (React + Vite + Capacitor)
│  │  └─ android/         ← پروژه نیتیو اندروید آماده بیلد
│  └─ driver/             ← اپ راننده
│     └─ android/
├─ packages/
│  └─ shared/             ← منطق مشترک: محاسبه کرایه، نقشه، ذخیره‌سازی، فرمت فارسی
└─ .github/workflows/
   └─ build-android.yml   ← بیلد خودکار APK در ابر (رایگان)
```

## ساخت APK در چهار گام (بدون نصب هیچ ابزاری)

1. محتویات این پوشه را در یک ریپوی GitHub آپلود کنید (از طریق خود سایت، با درگ‌اند‌دراپ؛ دقت کنید پوشه `.github` هم آپلود شود).
2. تب Actions به‌صورت خودکار workflow با نام «Build Passenger and Driver APKs» را اجرا می‌کند (۴ تا ۶ دقیقه).
3. پس از سبز شدن بیلد، از بخش Artifacts دو فایل `nova-passenger-debug` و `nova-driver-debug` را دانلود کنید (هر کدام zip حاوی `app-debug.apk` است).
4. فایل APK را به گوشی بفرستید و نصب کنید (اجازه «منابع ناشناس» را برای همان اپ فعال کنید).

## بیلد محلی (اختیاری)

اگر Android SDK و JDK 21 روی سیستمی در دسترس باشد:

```bash
npm ci
npm run build --workspace=apps/passenger
npx cap sync android --workspace=apps/passenger   # یا: cd apps/passenger && npx cap sync android
cd apps/passenger/android && ./gradlew assembleDebug
# خروجی: android/app/build/outputs/apk/debug/app-debug.apk
```

برای اپ راننده هم همین دستورها با `apps/driver` اجرا می‌شود.

## شخصی‌سازی

| چه چیزی | کجا |
|---|---|
| نام و شناسه اپ‌ها | `apps/passenger/capacitor.config.ts` و `apps/driver/capacitor.config.ts` |
| آیکون اپ‌ها | `apps/<app>/android/app/src/main/res/` (مجموعه کامل مipmap) |
| نرخ پایه و هر کیلومتر کرایه | `packages/shared/src/fare.ts` |
| لیست مکان‌ها و راننده‌های نمایشی | `packages/shared/src/data.ts` |
| رنگ‌بندی اپ‌ها | `apps/<app>/src/styles.css` |

## نکات فنی

- داده‌ها با پلاگین `@capacitor/preferences` روی خود دستگاه ذخیره می‌شوند (در وب به localStorage تبدیل می‌شود)؛ در این نسخه نمایشی سفارش‌ها و راننده‌ها شبیه‌سازی می‌شوند و اپ کاملاً آفلاین کار می‌کند.
- برای اتصال واقعی مسافر و راننده، بک‌اند (REST + WebSocket) لازم است؛ ساختار monorepo برای افزودن آن آماده است.
- نسخه‌های `debug` برای تست کافی‌اند؛ برای انتشار در گوگل‌پلی باید بیلد `release` امضاشده (AAB) ساخت — workflow قابل ارتقا است.
- نسخه Node لازم: ۲۰ یا ۲۲ (روی رانرهای GitHub از قبل موجود است). Java موردنیاز: ۲۱ (temurin در workflow تنظیم شده).

## ایموجی و مجوز

این پروژه برای استفاده شخصی/آموزشی نوشته شده است. نام برند «نوا» و هویت بصری آن قابل تغییر است.
